// import React from 'react'
// import "./style.css"
// import { Routes,Route,Navigate } from 'react-router-dom'
// import AddContact from './FunctionComponent/contact/AddContact'
// import ContactList from './FunctionComponent/contact/ContactList'
// import EditContact from './FunctionComponent/contact/EditContact'
// import ViewContact from './FunctionComponent/contact/ViewContact'
// import Navbar from './FunctionComponent/Navbar/Navbar'
// export default function App() {
//   return (
//     <>
//     <Navbar/>
//     <Routes>
//     <Route path={'/'} element={<Navigate to={'/contact/list'}/>}/>
//     <Route path={'/contact/list'} element={<ContactList/>}/>
//     <Route path={'/contact/add'} element={<AddContact/>}/>
//     <Route path={'/contact/view/:contactId'} element={<ViewContact/>}/>
//     <Route path={'/contact/edit/:contactId'} element={<EditContact/>}/>
//     </Routes>
//     </>
//   )
// }
// this is my main component we manage all thing in this file..
