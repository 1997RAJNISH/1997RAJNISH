// import React, { Component } from 'react'
// import { Routes,Route} from 'react-router-dom'
// import Navbar from './Navbar'
// import News from './News'

// export default class App extends Component {
//   constructor(){
//     super()
//     this.state={
//       language:"hi",
//     }
//   }
//   ChangeLanguage=(lang)=>{
//     this.setState({language:lang})
//   }
//   
//   render() {
//     return (
//         <>
//             <Navbar ChangeLanguage={this.ChangeLanguage}
//             />
//             <Routes>
//             <Route path='/' element={<News language={this.state.language} category="All"/>}></Route>
// <Route path='/Politics' element={<News language={this.state.language} category="Politics"/>}></Route>
// <Route path='/Crime' element={<News language={this.state.language} category="Crime"/>}></Route>
// <Route path='/Technology' element={<News language={this.state.language} category="Technology"/>}></Route>
// <Route path='/Science' element={<News language={this.state.language} category="Science"/>}></Route>
// <Route path='/Education' element={<News language={this.state.language} category="Education"/>}></Route>
// <Route path='/Sports' element={<News language={this.state.language} category="Sports"/>}></Route>
// <Route path='/IPL' element={<News language={this.state.language} category="IPL"/>}></Route>
// <Route path='/Covid19' element={<News language={this.state.language} category="Covid19"/>}></Route>
// <Route path='/Jokes' element={<News language={this.state.language} category="Jokes"/>}></Route>
// <Route path='/Entertainment' element={<News language={this.state.language} category="Entertainment"/>}></Route>
//             </Routes>
//         </>
//     )
//   }
// }

import React, { Component } from 'react'
import { Routes,Route } from 'react-router-dom'
import Navbar from './Navbar'
import News from './News'

export default class App extends Component {
    constructor() {
        super()
        this.state = {
            language:"hi"
        }
    }
    ChangeLanguage = (lang) => {
        this.setState({ language: lang })
    }
    render() {
        return (
            <>
                <Navbar
                    ChangeLanguage={this.ChangeLanguage}
                />
                <Routes>
                    <Route path='/' element={<News language={this.state.language} category="All" />}></Route>
                    <Route path='/Politics' element={<News language={this.state.language} category="Politics" />}></Route>
                    <Route path='/Crime' element={<News language={this.state.language} category="Crime" />}></Route>
                    <Route path='/Technology' element={<News language={this.state.language} category="Technology" />}></Route>
                    <Route path='/Science' element={<News language={this.state.language} category="Science" />}></Route>
                    <Route path='/Education' element={<News language={this.state.language} category="Education" />}></Route>
                    <Route path='/Sports' element={<News language={this.state.language} category="Sports" />}></Route>
                    <Route path='/IPL' element={<News language={this.state.language} category="IPL" />}></Route>
                    <Route path='/Covid19' element={<News language={this.state.language} category="Covid19" />}></Route>
                    <Route path='/Jokes' element={<News language={this.state.language} category="Jokes" />}></Route>
                    <Route path='/Entertainment' element={<News language={this.state.language} category="Entertainment" />}></Route>
                </Routes>
            </>
        )
    }
}




