// import React, { Component } from 'react'
// import NewsItem from './NewsItem'

// import InfiniteScroll from "react-infinite-scroll-component";
// export default class News extends Component {
//   constructor() {
//     super()
//     this.state = {
//       articles: [],
//       totalResults: 0,
//       page: 1,
//       pageSize: 8
//     }
//   }

//   async getdata() {
//     var rawdata = await fetch(`https://newsapi.org/v2/everything?q=${this.props.category}&language=${this.props.language}&page=${this.state.page}&pagesize=${this.state.pageSize}&apiKey=53b20e3d6aee4f00835a7043cdfd7f7c`)
//     var result = await rawdata.json()
//     this.setState({
//       articles: result.articles,
//       totalResults: result.totalResults,
//     })
//     //  console.log(result.totalResults);
//   }

//   componentDidMount() {
//     this.getdata()
//   }
//   componentDidUpdate(old) {
//     if (this.props.category !== old.category || this.props.language !== old.language)
//     this.getdata()
//   }

//   fetchMoreData = async () => {
//     this.setState({ page: this.state.page + 1 }) //jb fetchMore function call hoga to hme ek kaam krna hoga hme page change krna hoga
//     var rawdata = await fetch(`https://newsapi.org/v2/everything?q=${this.props.category}&language=${this.props.language}&page=${this.state.page}&pagesize=${this.state.pageSize}&apiKey=53b20e3d6aee4f00835a7043cdfd7f7c`)
//     var result = await rawdata.json()
//     this.setState({
//       articles: this.state.articles.concat(result.articles)
//     })
//   }




//   render() {
//     return (
//       <>
//         <h5 className='mt-2 bg-danger text-light p-2 text-center'>{this.props.category} News Section</h5>
//         <InfiniteScroll
//           dataLength={this.state.articles.length}
//           next={this.fetchMoreData}
//           hasMore={this.state.articles.length < this.state.totalResults}
//           loader={<h4>Loading...</h4>}
//         >
//           <div className='row'>
//             {
//                this.state.articles.map((item, index) => {
//                 return <div key={index} className='col-xxl-2 col-xl-2 col-lg-3 col-md-4 col-sm-6 col-12'>
//                   <NewsItem
// title={item.title}
// description={item.description}
// url={item.url}
// pic={item.urlToImage}
// source = {item.source}
// date = {item.publishedAt}

//                   />
//                 </div>
//               })
//             }
//           </div>
//         </InfiniteScroll>
//       </>
//     )
//   }
// }

import React, { Component } from 'react'
import NewsItem from './NewsItem'
import InfiniteScroll from "react-infinite-scroll-component";

export default class News extends Component {
    constructor() {
        super()
        this.state = {
            articles: [],
            totalResults: 0,
            page: 1,
            pageSize: 8
        }
    }
    async getdata() {
        var rawdata = await fetch(`https://newsapi.org/v2/everything?q=${this.props.category}&language=${this.props.language}&page=${this.state.page}&pageSize=${this.state.pageSize}&apiKey=53b20e3d6aee4f00835a7043cdfd7f7c`)
        var result = await rawdata.json()
        this.setState({
            articles: result.articles,
            totalResults: result.totalResults
        })
    }
    componentDidMount() {
        this.getdata()

    }
    componentDidUpdate(old) {
        if (this.props.category !== old.category || this.props.language !== old.language)
            this.getdata()
    }
    fetchMoreData=async()=>{
        this.setState({page:this.state.page+1})
        var rawdata = await fetch(`https://newsapi.org/v2/everything?q=${this.props.category}&language=${this.props.language}&page=${this.state.page}&pageSize=${this.state.pageSize}&apiKey=53b20e3d6aee4f00835a7043cdfd7f7c`)
        var result = await rawdata.json()
        this.setState({
            articles:this.state.articles.concat(result.articles)
        })
    }
    render() {
        return (
            <>
                <h5 className='mt-2 text-light bg-danger p-2 text-center'>{this.props.category} News Section</h5>
                <InfiniteScroll
          dataLength={this.state.articles.length}
          next={this.fetchMoreData}
          hasMore={this.state.articles.length<this.state.totalResults}
          loader={<h4>Loading...</h4>}
        >
                <div className='row'>
                    {
                        this.state.articles.map((item, index) => {
                            return <div key={index} className='col-xxl-2 col-xl-2 col-lg-3 col-md-4 col-sm-6 col-12'>
                                <NewsItem
                                    title={item.title}
                                    description={item.description}
                                    url={item.url}
                                    pic={item.urlToImage}
                                    source={item.source}
                                    date={item.publishedAt}
                                />
                            </div>
                        })
                    }
                </div>
                </InfiniteScroll>
            </>
        )
    }
}
