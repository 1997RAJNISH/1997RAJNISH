import React, { useState } from 'react'

export default function FormExample() {
    var[data,setdata]=useState({
        name:"",
        email:"@gmail.com",
        dsg:"",
        phone:"",
    })
    function getdata(e){
        var name=e.target.name
        var value=e.target.value
       setdata((olddata)=>{
        return{
            ...olddata,
            [name]:value
        }
       })

    }
    function postdata(e){
        e.preventDefault()
        console.log(`Name=${data.name} Email=${data.email} Dsg=${data.dsg} Phone=${data.phone}`);

    }

  return (
    <>
    <form onSubmit={postdata}>
    <input type='text' onChange={getdata} name='name' placeholder='Enter your name'/>
    <input type='text' onChange={getdata} name='email'  value={data.email}/>
    <input type='text' onChange={getdata} name='dsg' placeholder='Enter your Dsg'/>
    <input type='text' onChange={getdata} name='phone' placeholder='Enter your Phone'/>
    <button type='submit'>Submit</button>
    </form>
    </>
  )
}
