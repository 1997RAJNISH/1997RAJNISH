import React from 'react'
import { Link } from 'react-router-dom'

export default function AddContact() {
  return (
    <>
    <section className='add-contact'>
      <div className='container'>
        <div className='row'>
          <div className='col'>
          <p className='h4 text-primary fw-bold'>Create Contact</p>
          <p className='fst fst-italic'>This is the features of Add Contact. If i want to create contact then i can create.</p>
          </div>
        </div>
        <div className='row'>
          <div className='col-md-4'>
            <form>
              <div className='mb-2'>
                  <input type='text' className='form-control' placeholder='Enter your Name'/>
              </div>
              <div className='mb-2'>
                  <input type='text' className='form-control' placeholder='Enter your Photo Url'/>
              </div>
              <div className='mb-2'>
                  <input type='text' className='form-control' placeholder='Enter your Mobile'/>
              </div>
              <div className='mb-2'>
                  <input type='text' className='form-control' placeholder='Enter your Email Id'/>
              </div>
              <div className='mb-2'>
                  <input type='text' className='form-control' placeholder='Enter your City'/>
              </div>
              <div className='mb-2'>
                  <input type='text' className='form-control' placeholder='Enter your Designation'/>
              </div>
              <div className='mb-2'>
              <select className='form-control'>
                <option value=''>Select a Group</option>
              </select>
              </div>
              <div className='mb-2'>
                  <input type='submit' className='btn btn-success' value='Create'/>
                  <Link to={'/contact/list'} className='btn btn-dark ms-2'>Cancel</Link>
              </div>
            </form>
          </div>
        </div>
      </div>
    </section>
    </>
  )
}
