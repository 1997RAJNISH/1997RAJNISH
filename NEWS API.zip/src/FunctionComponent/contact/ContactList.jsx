import React from 'react'
import { Link } from 'react-router-dom'
export default function ContactList() {
    return (
        <>
            <section className='contact-search p-3'>
                <div className='container'>
                    <div className='grid'>
                        <div className='row'>
                            <div className='col'>
                                <p className='h3'>Contact Manager <Link to={'/contact/add'} className='btn btn-primary ms-2'>Click New</Link></p>
                                <p className='italic'>Hello my name is Rajnish Kumar and i am going to make a task USER MANAGEMENT AND CONTACT MANAGEMENT</p>
                            </div>
                        </div>
                        <div className='row'>
                            <div className='col-md-6'>
                                <form className='row'>
                                    <div className='col'>
                                        <div className='mb-2'>
                                            <input type='text' className='form-control' placeholder='Enter your search' />
                                        </div>
                                    </div>
                                    <div className='col'>
                                        <div className='mb-2'>
                                            <input type='submit' className='btn btn-outline-dark' value='Search'/>
                                        </div>
                                    </div> 
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </section>

            <section className='contact-list'>
                    <div className='container'>
                    <div className='row'>
                        <div className='col-md-6'>
                            <div className='card'>
                                <div className='cardbody'>
                                    <div className='row align-items-center'>
                                        <div className='col-md-4'>
                                            <img src="https://www.pngitem.com/pimgs/m/22-220721_circled-user-male-type-user-colorful-icon-png.png" className='contact-img' alt=" "></img>
                                        </div>
                                        <div className='col-md-6'>
                                            <ul className='list-group'>
                                                <li className='list-group-item list-group-item-action'>Name:<span className='fw-bold'>Rajnish Kumar</span></li>
                                                <li className='list-group-item list-group-item-action'>Mobile:<span className='fw-bold'>7368812660</span></li>
                                                <li className='list-group-item list-group-item-action'>Email:<span className='fw-bold'>rajnish071@gmail.com</span></li>
                                            </ul>
                                        </div>
                                        <div className='col-md-2 d-flex flex-column align-items-center'>
                                        <Link to={'/contact/view/:contactId'} className='btn btn-warning my-1'><i class="fa fa-eye"/></Link>
                                        <Link to={'/contact/edit/:contactId'} className='btn btn-primary my-1'><i class="fa fa-pen"/></Link>
                                        <button className='btn btn-danger my-1'><i class="fa fa-trash"/></button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            </div>
                            <div className='col-md-6'>
                            <div className='card'>
                                <div className='cardbody'>
                                    <div className='row align-items-center'>
                                        <div className='col-md-4'>
                                            <img src="https://www.pngitem.com/pimgs/m/22-220721_circled-user-male-type-user-colorful-icon-png.png" className='contact-img' alt=" "></img>
                                        </div>
                                        <div className='col-md-6'>
                                            <ul className='list-group'>
                                                <li className='list-group-item list-group-item-action'>Name:<span className='fw-bold'>Abhishek Soni</span></li>
                                                <li className='list-group-item list-group-item-action'>Mobile:<span className='fw-bold'>7903332512</span></li>
                                                <li className='list-group-item list-group-item-action'>Email:<span className='fw-bold'>abhishek@gmail.com</span></li>
                                            </ul>
                                        </div>
                                        <div className='col-md-2 d-flex flex-column align-items-center'>
                                        <Link to={'/contact/view/:contactId'} className='btn btn-warning my-1'><i class="fa fa-eye"/></Link>
                                        <Link to={'/contact/edit/:contactId'} className='btn btn-primary my-1'><i class="fa fa-pen"/></Link>
                                        <button className='btn btn-danger my-1'><i class="fa fa-trash"/></button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            </div>
                        </div>
                        </div>
                        </section>
                    </>
                    )
}
