import React from 'react'
import { Link } from 'react-router-dom'
export default function ViewContact() {
  return (
    <>
      <section className='view-contact'>
        <div className='container'>
          <div className='row'>
            <div className='column'>
              <p className='h3 text-success fw-bold'>View Contact</p>
              <p className='font-italic'>This is my View Contact..If i want to view our contact then This page is suitable for me..</p>
            </div>
          </div>
        </div>
      </section>

      <section className='view-contact mt-3'>
        <div className='container'>
          <div className='row align-items-center'>
            <div className='col-md-2'>
            <img src="https://www.pngitem.com/pimgs/m/22-220721_circled-user-male-type-user-colorful-icon-png.png" class="img-fluid" alt=" "></img>
            </div>
            <div className='col-md-8'>
              <ul className='list-group'>
                <li className='list-group-item list-group-item-action'>Name:<span className='fw-bold'>Rajnish Kumar</span></li>
                <li className='list-group-item list-group-item-action'>Photo Url:<span className='fw-bold'>https://www.pngitem.com/pimgs/m/22-220721_circled-user-male-type-user-colorful-icon-png.png</span></li>
                <li className='list-group-item list-group-item-action'>Mobile:<span className='fw-bold'>7368812660</span></li>
                <li className='list-group-item list-group-item-action'>Email:<span className='fw-bold'>rajnish071@gmail</span></li>
                <li className='list-group-item list-group-item-action'>Company:<span className='fw-bold'>Technogiq</span></li>
                <li className='list-group-item list-group-item-action'>Designation:<span className='fw-bold'>Frontend Developer</span></li>
                <li className='list-group-item list-group-item-action'>Group:<span className='fw-bold'>A+</span></li>
              </ul>
            </div>
          </div>
          <div className='row'>
            <div className='col'>
              <Link to={'/Contact/list'} className='btn btn-warning'>Back</Link>
            </div>
          </div>
        </div>
      </section>
    </>
  )
}
