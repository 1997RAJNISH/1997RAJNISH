
import React from 'react'
import ReactDOM from 'react-dom/client'
import { BrowserRouter } from 'react-router-dom'
import App from './ClassComponent/App'
var root=ReactDOM.createRoot(document.getElementById("root"))

root.render(
  <>
  <BrowserRouter>
    <App/>
  </BrowserRouter>
  </>
)


// import React from 'react'
// import ReactDOM from 'react-dom/client'
// import FormExample from './FunctionComponent/FormExample'
// var root=ReactDOM.createRoot(document.getElementById("root"))
// root.render(
//   <>
//     <FormExample/>
//   </>
// )

// import React from 'react'
// import ReactDOM from 'react-dom/client'
// import { BrowserRouter } from 'react-router-dom'
// import App from './ClassComponent/App'
// var root=ReactDOM.createRoot(document.getElementById("root"))
// root.render(
//   <>
//   <BrowserRouter>
//     <App/>
//   </BrowserRouter>
//   </>
// )



